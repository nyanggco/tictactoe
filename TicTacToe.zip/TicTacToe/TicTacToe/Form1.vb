﻿Public Class Form1
    Dim isX As Boolean
    Dim count As Integer
    Dim playerX As Integer
    Dim playerO As Integer

    Private Sub Enabled_False()
        Button1.Enabled = False
        Button2.Enabled = False
        Button3.Enabled = False
        Button4.Enabled = False
        Button5.Enabled = False
        Button6.Enabled = False
        Button7.Enabled = False
        Button8.Enabled = False
        Button9.Enabled = False
    End Sub
    Private Sub score()
        If (Button1.Text = "X" And Button2.Text = "X" And Button3.Text = "X") Then
            Enabled_False()
            Button1.BackColor = System.Drawing.Color.Red
            Button2.BackColor = System.Drawing.Color.Red
            Button3.BackColor = System.Drawing.Color.Red
            MessageBox.Show("Player X wins!", "tictactoe", MessageBoxButtons.OK, MessageBoxIcon.Information)
            playerX += 1
            Label7.Text = playerX
        ElseIf (Button1.Text = "O" And Button2.Text = "O" And Button3.Text = "O") Then
            Enabled_False()
            Button1.BackColor = System.Drawing.Color.Red
            Button2.BackColor = System.Drawing.Color.Red
            Button3.BackColor = System.Drawing.Color.Red
            MessageBox.Show("Player O wins!", "tictactoe", MessageBoxButtons.OK, MessageBoxIcon.Information)
            playerO += 1
            Label8.Text = playerO
        ElseIf (Button1.Text = "X" And Button4.Text = "X" And Button7.Text = "X") Then
            Enabled_False()
            Button1.BackColor = System.Drawing.Color.Red
            Button4.BackColor = System.Drawing.Color.Red
            Button7.BackColor = System.Drawing.Color.Red
            MessageBox.Show("Player X wins!", "tictactoe", MessageBoxButtons.OK, MessageBoxIcon.Information)
            playerX += 1
            Label7.Text = playerX
        ElseIf (Button1.Text = "O" And Button4.Text = "O" And Button7.Text = "O") Then
            Enabled_False()
            Button1.BackColor = System.Drawing.Color.Red
            Button4.BackColor = System.Drawing.Color.Red
            Button7.BackColor = System.Drawing.Color.Red
            MessageBox.Show("Player O wins!", "tictactoe", MessageBoxButtons.OK, MessageBoxIcon.Information)
            playerO += 1
            Label8.Text = playerO
        ElseIf (Button1.Text = "X" And Button5.Text = "X" And Button9.Text = "X") Then
            Enabled_False()
            Button1.BackColor = System.Drawing.Color.Red
            Button5.BackColor = System.Drawing.Color.Red
            Button9.BackColor = System.Drawing.Color.Red
            MessageBox.Show("Player X wins!", "tictactoe", MessageBoxButtons.OK, MessageBoxIcon.Information)
            playerX += 1
            Label7.Text = playerX
        ElseIf (Button1.Text = "O" And Button5.Text = "O" And Button9.Text = "O") Then
            Enabled_False()
            Button1.BackColor = System.Drawing.Color.Red
            Button5.BackColor = System.Drawing.Color.Red
            Button9.BackColor = System.Drawing.Color.Red
            MessageBox.Show("Player O wins!", "tictactoe", MessageBoxButtons.OK, MessageBoxIcon.Information)
            playerO += 1
            Label8.Text = playerO
        ElseIf (Button2.Text = "X" And Button5.Text = "X" And Button8.Text = "X") Then
            Enabled_False()
            Button2.BackColor = System.Drawing.Color.Red
            Button5.BackColor = System.Drawing.Color.Red
            Button8.BackColor = System.Drawing.Color.Red
            MessageBox.Show("Player X wins!", "tictactoe", MessageBoxButtons.OK, MessageBoxIcon.Information)
            playerX += 1
            Label7.Text = playerX
        ElseIf (Button2.Text = "O" And Button5.Text = "O" And Button8.Text = "O") Then
            Enabled_False()
            Button2.BackColor = System.Drawing.Color.Red
            Button5.BackColor = System.Drawing.Color.Red
            Button8.BackColor = System.Drawing.Color.Red
            MessageBox.Show("Player O wins!", "tictactoe", MessageBoxButtons.OK, MessageBoxIcon.Information)
            playerO += 1
            Label8.Text = playerO
        ElseIf (Button3.Text = "X" And Button5.Text = "X" And Button7.Text = "X") Then
            Enabled_False()
            Button3.BackColor = System.Drawing.Color.Red
            Button5.BackColor = System.Drawing.Color.Red
            Button7.BackColor = System.Drawing.Color.Red
            MessageBox.Show("Player X wins!", "tictactoe", MessageBoxButtons.OK, MessageBoxIcon.Information)
            playerX += 1
            Label7.Text = playerX
        ElseIf (Button3.Text = "O" And Button5.Text = "O" And Button7.Text = "O") Then
            Enabled_False()
            Button3.BackColor = System.Drawing.Color.Red
            Button5.BackColor = System.Drawing.Color.Red
            Button7.BackColor = System.Drawing.Color.Red
            MessageBox.Show("Player O wins!", "tictactoe", MessageBoxButtons.OK, MessageBoxIcon.Information)
            playerO += 1
            Label8.Text = playerO
        ElseIf (Button3.Text = "X" And Button6.Text = "X" And Button9.Text = "X") Then
            Enabled_False()
            Button3.BackColor = System.Drawing.Color.Red
            Button6.BackColor = System.Drawing.Color.Red
            Button9.BackColor = System.Drawing.Color.Red
            MessageBox.Show("Player X wins!", "tictactoe", MessageBoxButtons.OK, MessageBoxIcon.Information)
            playerX += 1
            Label7.Text = playerX
        ElseIf (Button3.Text = "O" And Button6.Text = "O" And Button9.Text = "O") Then
            Enabled_False()
            Button3.BackColor = System.Drawing.Color.Red
            Button6.BackColor = System.Drawing.Color.Red
            Button9.BackColor = System.Drawing.Color.Red
            MessageBox.Show("Player O wins!", "tictactoe", MessageBoxButtons.OK, MessageBoxIcon.Information)
            playerO += 1
            Label8.Text = playerO
        ElseIf (Button4.Text = "X" And Button5.Text = "X" And Button6.Text = "X") Then
            Enabled_False()
            Button4.BackColor = System.Drawing.Color.Red
            Button5.BackColor = System.Drawing.Color.Red
            Button6.BackColor = System.Drawing.Color.Red
            MessageBox.Show("Player X wins!", "tictactoe", MessageBoxButtons.OK, MessageBoxIcon.Information)
            playerX += 1
            Label7.Text = playerX
        ElseIf (Button4.Text = "O" And Button5.Text = "O" And Button6.Text = "O") Then
            Enabled_False()
            Button4.BackColor = System.Drawing.Color.Red
            Button5.BackColor = System.Drawing.Color.Red
            Button6.BackColor = System.Drawing.Color.Red
            MessageBox.Show("Player O wins!", "tictactoe", MessageBoxButtons.OK, MessageBoxIcon.Information)
            playerO += 1
            Label8.Text = playerO
        ElseIf (Button7.Text = "X" And Button8.Text = "X" And Button9.Text = "X") Then
            Enabled_False()
            Button7.BackColor = System.Drawing.Color.Red
            Button8.BackColor = System.Drawing.Color.Red
            Button9.BackColor = System.Drawing.Color.Red
            MessageBox.Show("Player X wins!", "tictactoe", MessageBoxButtons.OK, MessageBoxIcon.Information)
            playerX += 1
            Label7.Text = playerX
        ElseIf (Button7.Text = "O" And Button8.Text = "O" And Button9.Text = "O") Then
            Enabled_False()
            Button7.BackColor = System.Drawing.Color.Red
            Button8.BackColor = System.Drawing.Color.Red
            Button9.BackColor = System.Drawing.Color.Red
            MessageBox.Show("Player O wins!", "tictactoe", MessageBoxButtons.OK, MessageBoxIcon.Information)
            playerO += 1
            Label8.Text = playerO
        End If


    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click

    End Sub

    Private Sub Btn2_Clk(sender As Object, e As EventArgs) Handles Button2.Click
        count += 1
        If (count = 0 Or count = 2 Or count = 4 Or count = 6 Or count = 8) Then
            Button2.Text = "O"
            Button2.Enabled = False
            isX = False
            score()

        Else
            Button2.Text = "X"
            Button2.Enabled = False
            isX = True
            score()
        End If

    End Sub

    Private Sub Btn1_Clk(sender As Object, e As EventArgs) Handles Button1.Click
        count += 1
        If (count = 0 Or count = 2 Or count = 4 Or count = 6 Or count = 8) Then
            Button1.Text = "O"
            Button1.Enabled = False
            isX = False
            score()
        Else
            Button1.Text = "X"
            Button1.Enabled = False
            isX = True
            score()
        End If
    End Sub

    Private Sub Btn3_Clk(sender As Object, e As EventArgs) Handles Button3.Click
        count += 1
        If (count = 0 Or count = 2 Or count = 4 Or count = 6 Or count = 8) Then
            Button3.Text = "O"
            Button3.Enabled = False
            isX = False
            score()
        Else
            Button3.Text = "X"
            Button3.Enabled = False
            isX = True
            score()
        End If
    End Sub

    Private Sub Btn4_Clk(sender As Object, e As EventArgs) Handles Button4.Click
        count += 1
        If (count = 0 Or count = 2 Or count = 4 Or count = 6 Or count = 8) Then
            Button4.Text = "O"
            Button4.Enabled = False
            isX = False
            score()
        Else
            Button4.Text = "X"
            Button4.Enabled = False
            isX = True
            score()
        End If
    End Sub

    Private Sub Btn5_Clk(sender As Object, e As EventArgs) Handles Button5.Click
        count += 1
        If (count = 0 Or count = 2 Or count = 4 Or count = 6 Or count = 8) Then
            Button5.Text = "O"
            Button5.Enabled = False
            isX = False
            score()
        Else
            Button5.Text = "X"
            Button5.Enabled = False
            isX = True
            score()
        End If
    End Sub

    Private Sub Btn6_Clk(sender As Object, e As EventArgs) Handles Button6.Click
        count += 1
        If (count = 0 Or count = 2 Or count = 4 Or count = 6 Or count = 8) Then
            Button6.Text = "O"
            Button6.Enabled = False
            isX = False
            score()
        Else
            Button6.Text = "X"
            Button6.Enabled = False
            isX = True
            score()
        End If
    End Sub

    Private Sub Btn7_Clk(sender As Object, e As EventArgs) Handles Button7.Click
        count += 1
        If (count = 0 Or count = 2 Or count = 4 Or count = 6 Or count = 8) Then
            Button7.Text = "O"
            Button7.Enabled = False
            isX = False
            score()
        Else
            Button7.Text = "X"
            Button7.Enabled = False
            isX = True
            score()
        End If
    End Sub

    Private Sub Btn8_Clk(sender As Object, e As EventArgs) Handles Button8.Click
        count += 1
        If (count = 0 Or count = 2 Or count = 4 Or count = 6 Or count = 8) Then
            Button8.Text = "O"
            Button8.Enabled = False
            isX = False
            score()
        Else
            Button8.Text = "X"
            Button8.Enabled = False
            isX = True
            score()
        End If
    End Sub

    Private Sub Btn9_Clk(sender As Object, e As EventArgs) Handles Button9.Click
        count += 1
        If (count = 0 Or count = 2 Or count = 4 Or count = 6 Or count = 8) Then
            Button9.Text = "O"
            Button9.Enabled = False
            isX = False
            score()
        Else
            Button9.Text = "X"
            Button9.Enabled = False
            isX = True
            score()
        End If
    End Sub

    Private Sub Button10_Click(sender As Object, e As EventArgs) Handles Button10.Click
        Button1.Enabled = True
        Button2.Enabled = True
        Button3.Enabled = True
        Button4.Enabled = True
        Button5.Enabled = True
        Button6.Enabled = True
        Button7.Enabled = True
        Button8.Enabled = True
        Button9.Enabled = True

        Button1.Text = ""
        Button2.Text = ""
        Button3.Text = ""
        Button4.Text = ""
        Button5.Text = ""
        Button6.Text = ""
        Button7.Text = ""
        Button8.Text = ""
        Button9.Text = ""

        Button1.BackColor = Color.Transparent
        Button2.BackColor = Color.Transparent
        Button3.BackColor = Color.Transparent
        Button4.BackColor = Color.Transparent
        Button5.BackColor = Color.Transparent
        Button6.BackColor = Color.Transparent
        Button7.BackColor = Color.Transparent
        Button8.BackColor = Color.Transparent
        Button9.BackColor = Color.Transparent

        count = 0
    End Sub

    Private Sub Button11_Click(sender As Object, e As EventArgs) Handles Button11.Click
        Button1.Enabled = True
        Button2.Enabled = True
        Button3.Enabled = True
        Button4.Enabled = True
        Button5.Enabled = True
        Button6.Enabled = True
        Button7.Enabled = True
        Button8.Enabled = True
        Button9.Enabled = True

        Button1.Text = ""
        Button2.Text = ""
        Button3.Text = ""
        Button4.Text = ""
        Button5.Text = ""
        Button6.Text = ""
        Button7.Text = ""
        Button8.Text = ""
        Button9.Text = ""

        Button1.BackColor = Color.Transparent
        Button2.BackColor = Color.Transparent
        Button3.BackColor = Color.Transparent
        Button4.BackColor = Color.Transparent
        Button5.BackColor = Color.Transparent
        Button6.BackColor = Color.Transparent
        Button7.BackColor = Color.Transparent
        Button8.BackColor = Color.Transparent
        Button9.BackColor = Color.Transparent

        count = 0
        playerO = 0
        playerX = 0
        Label7.Text = playerX
        Label8.Text = playerO
    End Sub
End Class
